
// List of questions 

const questions = [
    {
        question: "Who is the greatest of all?",
        answers: [
            { text: "Humans", correct: false },
            { text: "Animals", correct: false },
            { text: "God", correct: true },
            { text: "Nature", correct: false },
        ]
    },
    {
        question: "You must be thankful to?",
        answers: [
            { text: "All", correct: true },
            { text: "None", correct: false },
            { text: "Both are correct", correct: false },
            { text: "NOTA", correct: false },
        ]
    },
    {
        question: "World is created because of?",
        answers: [
            { text: "Nature", correct: false },
            { text: "Universe", correct: false },
            { text: "Both above are correct", correct: false },
            { text: "Big Bang", correct: true },
        ]
    },
    {
        question: "Pleasure is which emotion?",
        answers: [
            { text: "Productive", correct: false },
            { text: "Temporary", correct: true },
            { text: "Permanent", correct: false },
            { text: "Disciplinary", correct: false },
        ]
    }
];

const questionElement = document.getElementById("question");
const answerBtns = document.getElementById("answer-btn");
const nextBtn = document.getElementById("next-btn");

// Initial score and question number 

let currentQuestionIndex = 0;
let score = 0;

// Function to start the quiz 

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextBtn.innerText = "NEXT";
    showQuestion();
}

// Will diaplay quesions from above array in buttions of questions class (HTML) 

function showQuestion() {
    resetState();
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.innerText = currentQuestion.question;
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerText = answer.text;
        button.classList.add("btn");
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
        answerBtns.appendChild(button);
    });
}

// it will hide the next button if answer is not selected it also clears previos options 

function resetState() {
    nextBtn.style.display = "none";
    while (answerBtns.firstChild) {
        answerBtns.removeChild(answerBtns.firstChild);
    }
}

// to select answer 

function selectAnswer(e) {
    const selectedBtn = e.target;
    const correct = selectedBtn.dataset.correct === "true";
    setStatusClass(selectedBtn, correct);
    Array.from(answerBtns.children).forEach(button => {
        button.disabled = true;
    });
    nextBtn.style.display = "block"; // Display next button
}

// to check the answer is correct or not {ref style.css #next-btn:hover:not([disabled]) } 

function setStatusClass(element, correct) {
    clearStatusClass(element);
    if (correct) {
        element.classList.add("correct");
        score++;
    } else {
        element.classList.add("incorrect");
    }
    // Highlight correct answer if not selected
    Array.from(answerBtns.children).forEach(button => {
        if (button.dataset.correct === "true" && !button.classList.contains("correct")) {
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextBtn.style.display = "block";
}


function clearStatusClass(element) {
    element.classList.remove("correct");
    element.classList.remove("incorrect"); 
}

// below function shows score 

function showScore() {
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length} !!`;
    nextBtn.innerHTML = "Play Again";
    nextBtn.style.background = "aqua";
    nextBtn.style.color = "black";
    nextBtn.style.display = "block";
}

// will check if the question is last or remaining 

function handleNextbutton() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showScore();
    }
}
nextBtn.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length) {
        handleNextbutton();
    } else {
        startQuiz();
    }
});

// to restart quiz 

document.addEventListener("DOMContentLoaded", startQuiz);

